package ContactTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

import contacts.Contact;


public class ContactTest {
	// Tests for the successful validation of a contact should pass
	@Test
	void testSuccessPath() throws ValidationException {
		Contact contact = new Contact("1", "name", "lastName", "7182706723", "51 Linden St");
		assertThat(contact)
			.isNotNull()
			.hasFieldOrPropertyWithValue("id", "1")
			.hasFieldOrPropertyWithValue("firstName", "name")
			.hasFieldOrPropertyWithValue("lastName", "lastName")
			.hasFieldOrPropertyWithValue("number", "7182706723")
			.hasFieldOrPropertyWithValue("address", "51 Linden St");
	}
	
	//Tests to assert first name inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestFirstName() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", null, "lastName", "7182706723", "51 Linden St");
	                });
	                assertEquals("firstName must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "", "lastName", "7182706723", "51 Linden St");
	                });
	                assertEquals("firstName must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "thisnameistoolong", "lastName", "7182706723", "51 Linden St");
	                });
	                assertEquals("firstName must be at least 1 and no greater than 10 characters in length", exception.getMessage());
	            }
	        );
	}
	//Tests to assert last name inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestLastName() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", null, "7182706723", "51 Linden St");
	                });
	                assertEquals("lastName must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "", "7182706723", "51 Linden St");
	                });
	                assertEquals("lastName must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastNameeeeeeeee", "7182706723", "51 Linden St");
	                });
	                assertEquals("lastName must be at least 1 and no greater than 10 characters in length", exception.getMessage());
	            }
	        );
	}
	//Tests to assert id inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestId() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact(null, "John", "lastName", "7182706723", "51 Linden St");
	                });
	                assertEquals("id must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("", "", "lastName", "7182706723", "51 Linden St");
	                });
	                assertEquals("id must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("11111111111", "John", "lastName", "7182706723", "51 Linden St");
	                });
	                assertEquals("id must be at least 1 and no greater than 10 characters in length", exception.getMessage());
	            }
	        );
	}
	//Tests to assert number inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestNumber() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastName", null, "51 Linden St");
	                });
	                assertEquals("number must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastName", "", "51 Linden St");
	                });
	                assertEquals("number must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastName", "71827067233", "51 Linden St");
	                });
	                assertEquals("number must be at least 10 and no greater than 10 characters in length", exception.getMessage());
	            }
	        );
	}
	//Tests to assert address inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestAddress() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastName", "7182706723", null);
	                });
	                assertEquals("address must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastName", "7182706723", "");
	                });
	                assertEquals("address must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Contact("1", "John", "lastName", "7182706723", "51 Linden Stttttttttttttttttttttttt");
	                });
	                assertEquals("address must be at least 1 and no greater than 30 characters in length", exception.getMessage());
	            }
	        );
	}
	
}
