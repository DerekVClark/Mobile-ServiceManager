package org.snhu.cs320.TaskServiceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.task.Task;
import org.snhu.cs320.task.TaskService;


class TaskServiceTest {
	private TaskService service;
	
	@BeforeEach
	void init() {
		TaskService.INSTANCE = null;
		service = TaskService.getInstance();
	}
	// Tests for adding task success should pass
	@Test
	void addSuccess() throws ValidationException {
		Task task = new Task("12345", "First", "Some description.");
		service.add(task);
		assertThat(service.repository)
			.containsKey("12345");
	}
	//Test for unsuccessful addition of task due to already in use id
	@Test
	void addUnsuccessful() throws ValidationException{
		Task task = new Task("123456", "First", "Some description.");
		service.add(task);
		assertThrows(IllegalArgumentException.class, ()->{new Task("123456", "First", "Some description.");
		service.add(task);});
	}
	// Test for deletion of task should pass
	@Test
	void delete() throws ValidationException {
		service.add(new Task("12345", "First", "Some description."));
		service.remove("12345");
		assertThat(service.repository)
			.doesNotContainKey("12345");
	}
	// Tests for a failure of deletion of a task due to invalid id should assert error
	@Test
	void failDelete() throws ValidationException {
		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.remove("1234");
		});
        assertEquals("A task with the ID [1234] does not exist.", exception.getMessage());
	}
	// Tests for successful updating of a task should pass
	@Test
	void updateSuccess() throws ValidationException {
		service.add(new Task("12345", "First", "Some description"));
		Task updatedTask = new Task("12345", "Name", "Updated Task Description");
		service.update(updatedTask);
		
		assertThat(service.repository)
			.extracting("12345")
			.hasFieldOrPropertyWithValue("name", "Name");
	}
	// Tests for unsuccessful updating of a task because the id's do not match and the id being updated does not exist
	@Test
	void updateFail() throws ValidationException {
		service.add(new Task("12345", "First", "Some descirption"));
		Task updatedTask = new Task("1", "Name", "Updated Task Description");
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.update(updatedTask);
		});
	}
	
}
