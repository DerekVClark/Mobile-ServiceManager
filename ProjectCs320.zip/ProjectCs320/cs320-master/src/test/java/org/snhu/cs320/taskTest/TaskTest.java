package org.snhu.cs320.taskTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.task.Task;



public class TaskTest {
	// Tests for the successful validation of a task should pass
	@Test
	void testSuccessPath() throws ValidationException {
		Task task = new Task("1", "name", "Description");
		assertThat(task)
			.isNotNull()
			.hasFieldOrPropertyWithValue("id", "1")
			.hasFieldOrPropertyWithValue("name", "name")
			.hasFieldOrPropertyWithValue("description", "Description");
	}
	//Tests to assert id inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestId() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task(null, "John", "Description");
	                });
	                assertEquals("id must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("", "John", "Description");
	                });
	                assertEquals("id must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("11111111111", "John", "Description");
	                });
	                assertEquals("id must be at least 1 and no greater than 10 characters in length", exception.getMessage());
	            }
	        );
	}
	//Tests to assert name inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestName() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("1", null, "Description");
	                });
	                assertEquals("name must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("1", "", "Description");
	                });
	                assertEquals("name must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("1", "JohnIsTooLongOfANameToBeInThisField", "Description");
	                });
	                assertEquals("name must be at least 1 and no greater than 20 characters in length", exception.getMessage());
	            }
	        );
	}
	//Tests to assert description inputs of null value, blank value or too long value are denied and a validation exception is thrown
	@Test
	public void failTestDescription() throws ValidationException {
		assertAll(
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("1", "John", null);
	                });
	                assertEquals("description must not be null", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("1", "John", "");
	                });
	                assertEquals("description must not be blank", exception.getMessage());
	            },
	            () -> {
	                ValidationException exception = assertThrows(ValidationException.class, () -> {
	                    new Task("1", "John", "Description1111111111111111111111111111111111111111111111111");
	                });
	                assertEquals("description must be at least 1 and no greater than 50 characters in length", exception.getMessage());
	            }
	        );
	}
	
	
}
