package org.snhu.cs320.AppointmentTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;


import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.snhu.cs320.appointment.Appointment;
import org.snhu.cs320.exceptions.ValidationException;





public class AppointmentTest {
	// Tests for the successful validation of a appointment should pass
	@Test
	void testSuccessPathPresent() throws ValidationException {
		Appointment appointment = new Appointment("1", LocalDate.now(), "Description");
		assertThat(appointment)
			.isNotNull()
			.hasFieldOrPropertyWithValue("id", "1")
			.hasFieldOrPropertyWithValue("date", LocalDate.now())
			.hasFieldOrPropertyWithValue("description", "Description");
	}
	// Tests for the successful validation of an appointment given a future date
		@Test
		void testSuccessPathFuture() throws ValidationException {
			LocalDate currentDate = LocalDate.now();
			LocalDate futureDate = currentDate.plusDays(1);
			Appointment appointment = new Appointment("1", futureDate, "Description");
			assertThat(appointment)
				.isNotNull()
				.hasFieldOrPropertyWithValue("id", "1")
				.hasFieldOrPropertyWithValue("date", futureDate)
				.hasFieldOrPropertyWithValue("description", "Description");
		}
		//Tests to assert id inputs of null value, blank value or too long value are denied and a validation exception is thrown
		@Test
		public void failTestId() throws ValidationException {
			assertAll(
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                    new Appointment(null, LocalDate.now(), "Description");
		                });
		                assertEquals("id must not be null", exception.getMessage());
		            },
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                	new Appointment("", LocalDate.now(), "Description");
		                });
		                assertEquals("id must not be blank", exception.getMessage());
		            },
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                	new Appointment("11111111111", LocalDate.now(), "Description");
		                });
		                assertEquals("id must be at least 1 and no greater than 10 characters in length", exception.getMessage());
		            }
		        );
		}
		//Tests to assert description inputs of null value, blank value or too long value are denied and a validation exception is thrown
		@Test
		public void failTestDescription() throws ValidationException {
			assertAll(
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                    new Appointment("1", LocalDate.now(), null);
		                });
		                assertEquals("description must not be null", exception.getMessage());
		            },
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                	new Appointment("1", LocalDate.now(), "");
		                });
		                assertEquals("description must not be blank", exception.getMessage());
		            },
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                	new Appointment("1", LocalDate.now(), "DescriptionMustBeShorterThisIsTooLongOfADescriptionForThisFieldToValidate");
		                });
		                assertEquals("description must be at least 1 and no greater than 50 characters in length", exception.getMessage());
		            }
		        );
		}
		//Tests to assert date inputs of null value or past date are denied and exception is thrown
		@Test
		public void failTestDate() throws ValidationException {
			assertAll(
		            () -> {
		                ValidationException exception = assertThrows(ValidationException.class, () -> {
		                    new Appointment("1", LocalDate.now().minusDays(2), "Description");
		                });
		                assertEquals("date must be current or future date", exception.getMessage());
		            },
		            () -> {
		            	assertThrows(NullPointerException.class, () -> {
		                	new Appointment("1", null, "Description");
		                });
		            }
		        );
		}
	
}
