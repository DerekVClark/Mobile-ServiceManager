package org.snhu.cs320.AppointmentServiceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.appointment.Appointment;
import org.snhu.cs320.appointment.AppointmentService;
import org.snhu.cs320.exceptions.ValidationException;



class AppointmentServiceTest {
	private AppointmentService service;
	
	@BeforeEach
	void init() {
		AppointmentService.INSTANCE = null;
		service = AppointmentService.getInstance();
	}
	// Tests for adding appointments success should pass
	@Test
	void addSuccess() throws ValidationException {
		Appointment appointment = new Appointment("12345", LocalDate.now() , "Some description.");
		service.add(appointment);
		assertThat(service.repository)
			.containsKey("12345");
	}
	//Test for unsuccessful adding of an appointment due to appointment with id already existing
	@Test
	void addUnsuccessful() throws ValidationException{
		Appointment appointment = new Appointment("12345", LocalDate.now() , "Some description.");
		service.add(appointment);
		assertThrows(IllegalArgumentException.class, ()->{new Appointment("12345", LocalDate.now() , "Some description.");
		service.add(appointment);});
	}
	// Test for deletion of appointments should pass
	@Test
	void delete() throws ValidationException {
		service.add(new Appointment("12345", LocalDate.now(), "Some description."));
		service.remove("12345");
		assertThat(service.repository)
			.doesNotContainKey("12345");
	}
	// Tests for a failure of deletion of an appointment due to invalid id should assert error
	@Test
	void failDelete() throws ValidationException {
		assertThrows(IllegalArgumentException.class, ()-> {service.remove("1234");});
	}
	
}
