package ContactServiceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.task.TaskService;

import contacts.Contact;
import contacts.ContactService;

public class ContactServiceTest {
	private ContactService service;
	
	@BeforeEach
	void init() {
		TaskService.INSTANCE = null;
		service = ContactService.getInstance();
	}
	// Tests for adding contact success should pass
	@Test
	void addSuccess() throws ValidationException {
		Contact contact = new Contact("12", "Firstname", "lastName", "7183708967", "address");
		service.add(contact);
		assertThat(service.repository)
			.containsKey("12");
	}
	// Tests for unsuccessful addition of contact due to id already in use
	@Test
	void addUnsuccessful() throws ValidationException{
		Contact contact = new Contact("12345", "firstName", "lastName", "7186709876" , "address");
		service.add(contact);
		assertThrows(IllegalArgumentException.class, ()->{new Contact("12345", "firstName", "lastName", "7186709876" , "address");
		service.add(contact);});
	}
	
	// Test for deletion of contact should pass
	@Test
	void delete() throws ValidationException {
		service.add(new Contact("12345", "Firstname", "lastName", "7183708967", "Some address"));
		service.remove("12345");
		assertThat(service.repository)
			.doesNotContainKey("12345");
	}
	// Tests for a failure of deletion of a contact due to invalid id should assert error
	@Test
	void failDelete() throws ValidationException {
		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.remove("1234");
		});
        assertEquals("A contact with the ID [1234] does not exist.", exception.getMessage());
	}
	// Tests for successful updating of a contact should pass
	@Test
	void updateSuccess() throws ValidationException {
		service.add(new Contact("1234", "Firstname", "lastName", "7183708967", "Some address"));
		Contact updatedContact = new Contact("1234", "FirstName2", "lastName", "7183708967", "Some address");
		service.update(updatedContact);
		
		assertThat(service.repository)
			.extracting("1234")
			.hasFieldOrPropertyWithValue("firstName", "FirstName2");
	}
	// Tests for unsuccessful updating of a contact because the id's do not match and the id being updated does not exist
	@Test
	void updateFail() throws ValidationException {
		service.add(new Contact("123456", "Firstname", "lastName", "7183708967", "Some address"));
		Contact updatedContact = new Contact("1", "Firstname", "lastName", "7183708967", "Some address");
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.update(updatedContact);
		});
	}
}
