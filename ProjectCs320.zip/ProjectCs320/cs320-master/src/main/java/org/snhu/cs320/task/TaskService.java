package org.snhu.cs320.task;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.snhu.cs320.exceptions.ValidationException;





public class TaskService {
	public static TaskService INSTANCE;
	// Creates public map of tasks called repository key value pairs
	public Map<String, Task> repository;
	
	private TaskService() {
		repository = new ConcurrentHashMap<>();
	}
	// Singleton design pattern
	public static synchronized TaskService getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new TaskService();
		}
		return INSTANCE;
	}
	// Get task id method
	public Task getTask(String taskId) {
        return repository.get(taskId);
    }
	// Adds task to repository if new id
	public void add(final Task task) {
		if(repository.containsKey(task.getId())) {
			throw new IllegalArgumentException(String.format("A task with the ID [%s] already exists.", task.getId()));
		}
		repository.put(task.getId(), task);
	}
	// Removes task with id if id exists
	public void remove(final String taskId) {
		if(!repository.containsKey(taskId)) {
			throw new IllegalArgumentException(String.format("A task with the ID [%s] does not exist.", taskId));
		}
		repository.remove(taskId);
	}
	// Removes and updates task with id if id exists in repository
	public void update(final Task updatedTask) {
		try {
		updatedTask.validate();
		} catch (ValidationException e) {
			throw new IllegalArgumentException("Invalid task: " + e.getMessage(), e);
		}
		if(!repository.containsKey(updatedTask.getId())) {
			throw new IllegalArgumentException(String.format("A contact with the ID [%s] does not exist.", updatedTask.getId()));
		}
		
		
		
		repository.put(updatedTask.getId(), updatedTask);
	}
}
