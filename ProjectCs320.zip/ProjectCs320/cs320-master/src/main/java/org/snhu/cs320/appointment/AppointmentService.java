package org.snhu.cs320.appointment;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AppointmentService {
	public static AppointmentService INSTANCE;
	// Creates public map of appointments called repository key value pairs
	public Map<String, Appointment> repository;
	
	private AppointmentService() {
		repository = new ConcurrentHashMap<>();
	}
	// Singleton design pattern
	public static synchronized AppointmentService getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new AppointmentService();
		}
		return INSTANCE;
	}
	// Get appointment id method
	public Appointment getAppointment(String appointmentId) {
        return repository.get(appointmentId);
    }
	// Adds appointment to repository if new id
	public void add(final Appointment appointment) {
		if(repository.containsKey(appointment.getId())) {
			throw new IllegalArgumentException(String.format("An appointment with the ID [%s] already exists.", appointment.getId()));
		}
		try {
		repository.put(appointment.getId(), appointment);
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Invalid appointment: " + e.getMessage(), e);
		}
	}
	// Removes appointment with id if id exists
		public void remove(final String appointmentId) {
			if(!repository.containsKey(appointmentId)) {
				throw new IllegalArgumentException(String.format("An appointment with the ID [%s] does not exist.", appointmentId));
			}
			repository.remove(appointmentId);
		}
}