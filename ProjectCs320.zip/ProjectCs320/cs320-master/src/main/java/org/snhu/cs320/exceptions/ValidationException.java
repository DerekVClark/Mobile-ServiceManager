package org.snhu.cs320.exceptions;

public class ValidationException extends Exception {

	private static final long serialVersionUID = -2856119686187590091L;
	//Validation exception method for message and cause for validation exception
	//public ValidationException(String message, Throwable cause) {
		//super(message, cause);
	//}
	//Validation exception message
	public ValidationException(String message) {
		super(message);
	}
	
}
