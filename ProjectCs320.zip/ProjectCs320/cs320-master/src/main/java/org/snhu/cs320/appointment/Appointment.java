package org.snhu.cs320.appointment;

import java.time.LocalDate;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validation.Validation;

public class Appointment {
	
	private String id;
	private LocalDate date;
	private String description;
	//Create appointment with id date and description attributes
	public Appointment(String id, LocalDate date, String description) throws ValidationException {
		super();
		this.id = id;
		this.date = date;
		this.description = description;
		//validation function
		validate();
	}
	//gets appointment id
	public String getId() {
        return id;
    }
	//sets appointment description
	public void setDescription(String description) throws ValidationException {
		this.description = description;
		validate();
	}
	//Validation for each input field
	public void validate() throws ValidationException {
		// Validate ID
		Validation.validateNotBlank(id, "id");
		Validation.validateNotNull(id, "id");
		Validation.validateLength(id, "id", 1, 10);
		
		// Validate Date
		Validation.validateDate(date, "date");
		Validation.validateNotNull(date, "date");
	
		
		// Validate Description
		Validation.validateNotBlank(description, "description");
		Validation.validateNotNull(description, "description");
		Validation.validateLength(description, "description", 1, 50);
		
	}

}