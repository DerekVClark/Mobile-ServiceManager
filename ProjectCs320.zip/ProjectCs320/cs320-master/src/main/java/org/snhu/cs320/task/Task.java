package org.snhu.cs320.task;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validation.Validation;

public class Task {
	//Task fields id name and description
	private String id;
	private String name;
	private String description;
	//Create task with id name and description strings
	public Task(String id, String name, String description) throws ValidationException {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		//Validation method
		validate();
	}
	//gets task id
	public String getId() {
        return id;
    }

	//Validation for each input field
	void validate() throws ValidationException {
		// Validate ID
		Validation.validateNotBlank(id, "id");
		Validation.validateNotNull(id, "id");
		Validation.validateLength(id, "id", 1, 10);
		
		// Validate Name
		Validation.validateNotBlank(name, "name");
		Validation.validateNotNull(name, "name");
		Validation.validateLength(name, "name", 1, 20);
		
		// Validate Description
		Validation.validateNotBlank(description, "description");
		Validation.validateNotNull(description, "description");
		Validation.validateLength(description, "description", 1, 50);
		
	}

}
