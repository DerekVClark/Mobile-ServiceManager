package org.snhu.cs320.validation;


import java.time.LocalDate;

import org.snhu.cs320.exceptions.ValidationException;

public class Validation {
	
	private Validation() {}
	//Validates the input is not null if so passes validation exception message
	public static void validateNotNull(Object input, String label) throws ValidationException {
		if (input == null) {
			throw new ValidationException(label + " must not be null");
		}
	}
	// Validates if not blank if so passes validation exception message
	public static void validateNotBlank(String input, String label) throws ValidationException {
		validateNotNull(input, label);
		
		if (input.trim().length() < 1) {
			throw new ValidationException(label + " must not be blank");
		}
	}
	// Validates if between min length and max length if not passes exception message
	public static void validateLength(String input, String label, int minLength, int maxLength) throws ValidationException {
		if (input.length() < minLength || input.length() > maxLength) {
			throw new ValidationException(label + " must be at least " + minLength + " and no greater than " + maxLength + " characters in length");
		}
	}
	//Checks to see if that date is before the current date
	public static void validateDate(LocalDate date, String label) throws ValidationException {
		LocalDate today = LocalDate.now();
		if(date.isBefore(today)) {
			throw new ValidationException(label + " must be current or future date");
		}
	}
	
}