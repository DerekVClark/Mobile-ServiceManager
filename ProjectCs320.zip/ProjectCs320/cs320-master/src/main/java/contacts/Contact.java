package contacts;


import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validation.Validation;

public class Contact {
	private String id;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	//Create contact with first name, last name, number and address attributes
	public Contact(String id, String firstName, String lastName, String number, String address) throws ValidationException {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.address = address;
		//validation function
		validate();
	}
	//gets contact id
		public String getId() {
	        return id;
	    }
		//Validation for each input field
		public void validate() throws ValidationException {
			// Validate ID
			Validation.validateNotBlank(id, "id");
			Validation.validateNotNull(id, "id");
			Validation.validateLength(id, "id", 1, 10);
			// Validate first name
			Validation.validateNotBlank(firstName, "firstName");
			Validation.validateNotNull(firstName, "firstName");
			Validation.validateLength(firstName, "firstName", 1, 10);
			// Validate last name
			Validation.validateNotBlank(lastName, "lastName");
			Validation.validateNotNull(lastName, "lastName");
			Validation.validateLength(lastName, "lastName", 1, 10);
			// Validate phone number
			Validation.validateNotBlank(number, "number");
			Validation.validateNotNull(number, "number");
			Validation.validateLength(number, "number", 10, 10);
			// Validate address
			Validation.validateNotBlank(address, "address");
			Validation.validateNotNull(address, "address");
			Validation.validateLength(address, "address", 1, 30);
		}
}
