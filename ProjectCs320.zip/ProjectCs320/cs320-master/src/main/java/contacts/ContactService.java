package contacts;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ContactService {
	// Creates public map of appointments called repository key value pairs
	public static ContactService INSTANCE;
	public Map<String, Contact> repository;
	
	private ContactService() {
		repository = new ConcurrentHashMap<>();
	}
	//Singleton design
	public static synchronized ContactService getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ContactService();
		}
		return INSTANCE;
	}
	// Get contact id method
		public Contact getContact(String contactId) {
	        return repository.get(contactId);
	    }
	//Adds contact to repository if id does not already exist within
	public void add(final Contact contact) {
		if(repository.containsKey(contact.getId())) {
			throw new IllegalArgumentException(String.format("A contact with the ID [%s] already exists.", contact.getId()));
		}
		repository.put(contact.getId(), contact);
	}
	//Removes contact if id is in repository
	public void remove(final String contactId) {
		if(!repository.containsKey(contactId)) {
			throw new IllegalArgumentException(String.format("A contact with the ID [%s] does not exist.", contactId));
		}
		repository.remove(contactId);
	}
	//Updates contact if id is found within repository
	public void update(final Contact updatedContact) {
		if(!repository.containsKey(updatedContact.getId())) {
			throw new IllegalArgumentException(String.format("A contact with the ID [%s] does not exist.", updatedContact.getId()));
		}
		repository.remove(updatedContact.getId());
		
		repository.put(updatedContact.getId(), updatedContact);
	}
}
